# LEGACY (OUTDATED): BatchBridge — ERR-TLS-014 Unknown CA

**Last updated:** 2025-08-03  
**Status:** DEPRECATED — Use the newer troubleshooting guide.

## Warning
This document contains older steps that no longer apply after the 2026-01 certificate rollout.

## Old resolution (do not use)
- Import certificate manually into Java keystore (legacy JRE)

## New reference
See: `Troubleshoot_BatchBridge_ERR-TLS-014_UnknownCA.md`
